#include "ligne.h"

ligne::ligne(float xi, float yi, float xf, float yf, sf::Color Couleur)
{
	Xi = xi;
	Yi = yi;
	Xf = xf;
	Yf = yf;
	couleur = Couleur;
}
